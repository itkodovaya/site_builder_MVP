from builder.utils import add_composite_index_to_web_page_view


def execute():
	add_composite_index_to_web_page_view()
