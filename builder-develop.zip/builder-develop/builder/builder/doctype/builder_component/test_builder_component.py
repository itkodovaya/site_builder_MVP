# Copyright (c) 2023, asdf and Contributors
# See license.txt

# import frappe
from frappe.tests.utils import FrappeTestCase


class TestBuilderComponent(FrappeTestCase):
	pass
