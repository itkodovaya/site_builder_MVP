frappe.search.utils.make_function_searchable(
  () => window.open("/builder"),
  "Open Builder",
);
