# Frappe Builder

An easier way to build web pages for your needs!
